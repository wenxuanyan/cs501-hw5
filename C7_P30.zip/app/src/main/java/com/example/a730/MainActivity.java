package com.example.a730;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends Activity implements GestureDetector.OnDoubleTapListener{

    private TextView ranNum1;
    private TextView ranNum2;
    private TextView addOpp;
    private  TextView tvAns;
    private int num1;
    private int num2;
    private int result;
    private GestureDetector GD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ranNum1 = (TextView) findViewById(R.id.ranNum1);
        ranNum2 = (TextView) findViewById(R.id.ranNum2);
        addOpp = (TextView) findViewById(R.id.addOpp);
        tvAns = (TextView) findViewById(R.id.tvAns);

        num1 = randomNum();
        ranNum1.setText(Integer.toString(num1));
        num2 = randomNum();
        ranNum2.setText(Integer.toString(num2));
        result = num1 + num2;

        GD = new GestureDetector(this, new SimpleOnGestureListener(){
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                num1 = randomNum();
                num2 = randomNum();
                result = num1 + num2;

                ranNum1.setText(Integer.toString(num1));
                ranNum2.setText(Integer.toString(num2));
                tvAns.setText("");
                return super.onDoubleTap(e);
            }
        });

        addOpp.setOnTouchListener(new View.OnTouchListener() {
            private GestureDetector GD1 = new GestureDetector(MainActivity.this, new SimpleOnGestureListener(){
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    tvAns.setText(Integer.toString(result));

                    return super.onDoubleTap(e);
                }
            });
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                GD1.onTouchEvent(motionEvent);
                return true;
            }
        });


    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        GD.onTouchEvent(event);

        return super.onTouchEvent(event);
    }

    public int randomNum () {
        int random = new Random().nextInt((9 - 1) + 1) + 1;
        return random;
    }


    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        num1 = randomNum();
        num2 = randomNum();
        result = num1 + num2;

        ranNum1.setText(Integer.toString(num1));
        ranNum2.setText(Integer.toString(num2));
        tvAns.setText("");
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }
}