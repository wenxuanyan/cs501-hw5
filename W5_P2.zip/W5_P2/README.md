<h1>Workout App</h1>
<p>This app tracks significant shakes, hence it tracks number of steps/jumps</p>
<h1>Features</h1>
<p>The app includes a listview (for selecting a workout), two buttons (for starting and ending workouts), a textview for tracking number of steps/jumps. All workouts end automatically
after 100 significant shakes. Clicking stop will end a workout early. Stop means stop everything flashlight and music. After 10 significant shakes the flashlight should start blinking, but 
only for the easy workout. After 30 significant shakes the
flashlight should start blinking for
the medium and hard workouts. For the easy workout, choose a low
value for significant shake, and play
the theme from Superman after 30
shakes. For the medium workout, choose a
medium value for significant shake,
play the theme from Chariots of Fire
after 45 shakes. For the hard workout, choose a high
value for significant shake, play the
theme from Rocky after 60 shakes. </p>
