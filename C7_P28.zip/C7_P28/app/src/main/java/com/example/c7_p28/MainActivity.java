package com.example.c7_p28;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView mTextview;
    float startX = -1;
    float startY = -1;
    float dx,dy;
    int threshold = 100;
    int frequency = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextview = (TextView) findViewById(R.id.text);
        mTextview.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float newX, newY ;
                if(startX == -1 && startY == -1){
                    startX = v.getX();
                    startY = v.getY();
                }
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        dx = v.getX() - event.getRawX();
                        dy = v.getY() - event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        frequency++;
                        System.out.println("Sam Frequency: "+frequency);
                        newX = event.getRawX() + dx;
                        newY = event.getRawY() + dy;
                        if(frequency >threshold){
                            frequency = 0;
                            mTextview.setVisibility(View.INVISIBLE);
                            v.animate().x(100+dx).y(100-dy).setDuration(0).start();

                        }else if(newX != startX || newY != startY) {
                            v.animate().x(newX).y(newY)
                                    .setDuration(0)
                                    .start();

                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    mTextview.setVisibility(View.VISIBLE);
                    break;
                    default:
                        return false;
                }
                return true;
            }
        });
    }
}


